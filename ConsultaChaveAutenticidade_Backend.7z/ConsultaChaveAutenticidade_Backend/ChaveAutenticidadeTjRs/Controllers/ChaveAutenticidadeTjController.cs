using Microsoft.AspNetCore.Mvc;
using ChaveAutenticidadeSelos.Core.Dto;
using ChaveAutenticidadeSelos.Services.Interfaces;
using ChaveAutenticidadeTjRs.Shared;
using ChaveAutenticidadeTjRs.Services.Interfaces;

namespace ChaveAutenticidadeSelos.Controllers
{
    [Route("[controller]")]
    public class ChaveAutenticidadeTjController : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<List<DadosServentiaDto>>> ConsultarChaveAutenticidadeTJRs(
            [FromServices] IChaveAutenticidadeService _chaveAutenticidadeService,
            [FromServices] IValidacao _validacao,
            [FromQuery] List<string> chavesAutenticidade)
        {            
            List<string> erros =  _validacao.ValidarChavesList(chavesAutenticidade);
                
            if (erros.Count > 0)
                return BadRequest(erros);
            else
            {
                var result = await _chaveAutenticidadeService.ObterDadosChaveAutenticidade(chavesAutenticidade);

                return Ok(result);                
            }
            
        }
    }
}