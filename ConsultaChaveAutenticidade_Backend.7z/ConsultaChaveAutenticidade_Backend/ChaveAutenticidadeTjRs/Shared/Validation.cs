using System.Text.RegularExpressions;
using ChaveAutenticidadeTjRs.Services.Interfaces;

namespace ChaveAutenticidadeTjRs.Shared
{
    public class Validacao : IValidacao
    {
        public List<string> ValidarChavesList(List<string> chavesAutenticidade)
        {
            var errors = new List<string>();

            if (chavesAutenticidade.Count == 0)
            {   
                errors.Add("Ooops! Não foi encontrado chaves para consulta!");
            }

            foreach (var chave in chavesAutenticidade)
            {
                if (chave.Length != 22)
                {   
                    errors.Add("Oops! Chave de autenticidade inválida! Verifique sua chave.");                    
                }
                
                if (!Regex.IsMatch(chave,@"^[0-9]+$"))
                {
                    errors.Add("A chave de autenticidade deve conter somente números!");
                }                               
            }

            return errors; 
        }

        public List<string> ValidarResponse(string chave)
        {
            var errors = new List<string>();

            if (!chave.Contains("table"))
            {
                errors.Add("Oops! Chave não encontrada!");
            }

            return errors;
        }
    }
}

